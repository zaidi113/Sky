package sky.exercise.ondemand;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import sky.exercise.metadata.MovieService;
import sky.exercise.metadata.TechnicalFailureException;
import sky.exercise.metadata.TitleNotFoundException;

import static sky.exercise.ondemand.ParentalControlLevel.*;


@RunWith(MockitoJUnitRunner.class)
public class ParentalControlServiceTest {

    @Mock
    private MovieService movieService;


    @Test
    public void customerCannotWatchInCaseOfTechnicalException() throws TechnicalFailureException, TitleNotFoundException {

        String movieId = "Any Movie";
        Mockito.when(movieService.getParentalControlLevel(ArgumentMatchers.eq(movieId))).thenThrow(new TechnicalFailureException());

        ParentalControlService parentalControlService = new ParentalControlService(movieService);
        boolean actualWatchResult = parentalControlService.canCustomerWatchMovie(PARENTAL_GUIDANCE.getDescription(), movieId);

        Assert.assertFalse("Customer should not be able to watch in case of TechnicalFailureException", actualWatchResult);
        Mockito.verify(movieService).getParentalControlLevel(ArgumentMatchers.eq(movieId));
    }

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Test
    public void invalidMovieIdWillResultInAnException() throws TechnicalFailureException, TitleNotFoundException {

        String movieId = "Non Existing Movie";
        String exceptionMessage = "Unable to find the movie";

        expectedException.expect(TitleNotFoundException.class);
        expectedException.expectMessage(exceptionMessage);

        Mockito.when(movieService.getParentalControlLevel(ArgumentMatchers.eq(movieId))).thenThrow(new TitleNotFoundException(exceptionMessage));

        ParentalControlService parentalControlService = new ParentalControlService(movieService);
        parentalControlService.canCustomerWatchMovie(PARENTAL_GUIDANCE.getDescription(), movieId);

        Mockito.verify(movieService).getParentalControlLevel(ArgumentMatchers.eq(movieId));
    }

    @Test
    public void customerCanWatchWhenPreferredLevelIsEqualOrHigherThanTheMovieRatingLevel() throws TechnicalFailureException, TitleNotFoundException {

        String movieId = "Any Movie";

        Mockito.when(movieService.getParentalControlLevel(ArgumentMatchers.eq(movieId))).thenReturn(PARENTAL_GUIDANCE.getDescription());

        ParentalControlService parentalControlService = new ParentalControlService(movieService);

        boolean canWatch = parentalControlService.canCustomerWatchMovie(PARENTAL_GUIDANCE.getDescription(), movieId);
        Assert.assertTrue(canWatch);

        canWatch = parentalControlService.canCustomerWatchMovie(TWELVE.getDescription(), movieId);
        Assert.assertTrue(canWatch);

        canWatch = parentalControlService.canCustomerWatchMovie(EIGHTEEN.getDescription(), movieId);
        Assert.assertTrue(canWatch);

        canWatch = parentalControlService.canCustomerWatchMovie(UNIVERSAL.getDescription(), movieId);
        Assert.assertFalse(canWatch);
    }
}
