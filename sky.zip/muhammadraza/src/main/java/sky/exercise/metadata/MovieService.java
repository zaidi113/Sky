package sky.exercise.metadata;

public interface MovieService {
    String getParentalControlLevel(String movieId)
            throws TitleNotFoundException,
            TechnicalFailureException;
}