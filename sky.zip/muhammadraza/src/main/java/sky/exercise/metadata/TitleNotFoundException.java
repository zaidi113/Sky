package sky.exercise.metadata;

public class TitleNotFoundException extends Exception {

    public TitleNotFoundException(String message) {
        super(message);
    }
}
