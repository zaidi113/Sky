package sky.exercise.metadata;

public class TechnicalFailureException extends Exception {
}
