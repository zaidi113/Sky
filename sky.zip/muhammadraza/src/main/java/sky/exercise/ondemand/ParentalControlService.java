package sky.exercise.ondemand;


import sky.exercise.metadata.MovieService;
import sky.exercise.metadata.TechnicalFailureException;
import sky.exercise.metadata.TitleNotFoundException;

public class ParentalControlService {

    private final MovieService movieService;

    public ParentalControlService(MovieService movieService) {
        this.movieService = movieService;
    }

    /**
     *
     * @param parentalControlLevelPreference - Parent control level .e.g. U, PG etc
     * @param movieId - Id or Title of the movie
     * @return true if customer is allowed to watch movie, false otherwise.
     * @throws TitleNotFoundException - If movie id does not exist.
     */
    public boolean canCustomerWatchMovie(String parentalControlLevelPreference, String movieId) throws TitleNotFoundException {
        try {
            String movieParentalControlLevel = movieService.getParentalControlLevel(movieId);
            return isAllowedToWatch(parentalControlLevelPreference, movieParentalControlLevel);
        } catch (TechnicalFailureException e) {
            return false;
        }
    }

    /**
     * @param parentalControlLevelPreference - Customer's parental control level
     * @param movieParentalControlLevel - Movie's control level rating
     * @return true when movieParentalControlLevel's sensitivity is equal or less than the parentalControlLevelPreference's sensitivity
     */
    private boolean isAllowedToWatch(String parentalControlLevelPreference, String movieParentalControlLevel){

        ParentalControlLevel parentalControlLevel = ParentalControlLevel.fromDescription(parentalControlLevelPreference);
        ParentalControlLevel movieControlLevel = ParentalControlLevel.fromDescription(movieParentalControlLevel);
        return movieControlLevel.getSensitivity() <= parentalControlLevel.getSensitivity();
    }
}
