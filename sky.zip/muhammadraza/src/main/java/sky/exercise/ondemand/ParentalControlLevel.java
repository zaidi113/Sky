package sky.exercise.ondemand;

public enum ParentalControlLevel {

    UNIVERSAL("U", 0),
    PARENTAL_GUIDANCE("PG", 1),
    TWELVE("12", 2),
    FIFTEEN("15", 3),
    EIGHTEEN("18", 4);

    private String description;
    private int sensitivity;

    ParentalControlLevel(String description, int sensitivity) {
        this.description = description;
        this.sensitivity = sensitivity;
    }

    public static ParentalControlLevel fromDescription(String description){
        for (ParentalControlLevel parentalControlLevel : values()) {
            if(parentalControlLevel.description.equalsIgnoreCase(description)){
                return parentalControlLevel;
            }
        }
        throw new IllegalArgumentException("No such Parental Control Level found for value " + description );
    }


    public int getSensitivity() {
        return sensitivity;
    }

    public String getDescription() {
        return description;
    }
}
