1-  Environment Requirement
=========================================

Install Java 1.8 - It can be downloaded from https://www.java.com/en/download/
Install Maven 3.0.5

2-  Creating project using POM
=========================================
Using Java IDE like eclipse or Intellij,
Create a maven project and load the pom.xml file

3-  Running Test
=========================================
Go to the root folder and open up a command prompt or terminal

execute
    mvn clean package

The above command will execute Tests in the ParentalControlServiceTest

4- Navigating the source code
=========================================

Package sky.exercise.metadata contains API with no implementation
This is to compile the source code for our ParentalControlService

Package sky.exercise.ondemand contains the source code required by the Sky Team,